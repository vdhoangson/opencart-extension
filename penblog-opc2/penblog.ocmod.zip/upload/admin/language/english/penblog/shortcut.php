<?php
/* Shortcut */
$_['text_dashboard'] = 'Dashboard';
$_['text_category']  = 'Category';
$_['text_article']   = 'Article';
$_['text_comment']   = 'Comment';
$_['text_download']   = 'Download';
$_['text_poll']   = 'Poll';
$_['text_testimonial']   = 'Testimonial';
$_['text_setting']   = 'Setting';
$_['text_penblog_block']   = 'CMS Block';
$_['text_about']   = 'About Us';
?>