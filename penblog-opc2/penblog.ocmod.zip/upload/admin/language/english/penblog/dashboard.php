<?php
$_['heading_title'] = 'Pen Blog Dashboard';

$_['text_article'] = 'Article';
$_['text_total_article'] = 'Total Articles';
$_['text_public_article'] = 'Public Articles';
$_['text_unpublic_article'] = 'Unpublic Articles';

$_['text_category'] = 'Category';
$_['text_total_category'] = 'Total Category';
$_['text_public_category'] = 'Public Category';
$_['text_unpublic_category'] = 'Unpublic Category';

$_['text_comment'] = 'Comment';
$_['text_total_comment'] = 'Total Comment';
$_['text_public_comment'] = 'Public Comment';
$_['text_unpublic_comment'] = 'Unpublic Comment';

$_['column_name'] = 'Name';
$_['column_date_added'] = 'Date added';
$_['column_action'] = 'Action';
$_['column_category'] = 'Category';
$_['column_status'] = 'Status';
$_['text_latest_article'] = 'Latest Articles';
$_['text_latest_testimonial'] = 'Latest Testimonials';