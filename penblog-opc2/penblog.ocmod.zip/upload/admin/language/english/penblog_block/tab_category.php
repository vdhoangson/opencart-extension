<?php
$_['block_title'] = 'Tab - Category';

$_['entry_category'] = 'Category';