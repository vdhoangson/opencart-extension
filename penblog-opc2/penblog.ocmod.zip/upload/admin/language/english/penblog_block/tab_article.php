<?php
$_['block_title'] = 'Tab - Article';

$_['entry_article'] = 'Article';