<?php
$_['block_title'] = 'Article By Category';