<?php
$_['block_title'] = 'Calendar block';