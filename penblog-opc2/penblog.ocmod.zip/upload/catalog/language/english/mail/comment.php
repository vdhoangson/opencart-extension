<?php
// Text
$_['text_subject']	= '%s - Your Comment';
$_['text_waiting']	= 'You have a new product comment waiting.';
$_['text_product']	= 'Product: %s';
$_['text_viewer']	= 'Author: %s';
$_['text_rating']	= 'Rating: %s';
$_['text_comment']	= 'Comment:';