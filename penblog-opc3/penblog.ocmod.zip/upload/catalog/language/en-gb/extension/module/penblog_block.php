<?php
$_['text_readmore']      = 'Read more';
$_['text_date_added']    = 'Posted On';
$_['text_date_modified'] = 'Last Update';
$_['text_viewed']        = 'View';
$_['text_author']        = 'Author';
$_['text_empty']         = 'There are no articles to list in this category.';
?>