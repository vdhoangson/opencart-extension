<?php

$_['text_vote'] = 'Vote';
$_['text_no_poll'] = 'No Poll';
$_['text_no_votes'] = 'No votes';
$_['text_please_select_poll'] = 'Please select poll';
$_['text_total_votes'] = 'Total votes: ';
$_['text_poll_results'] = 'Poll results';