<?php
// Heading
$_['heading_title']     = 'About Me';
$_['penblog_dashboard']     = 'Dashboard';
$_['button_update']     = 'Update now';

$_['tab_info_update']     = 'Info & Update';
$_['tab_log']     = 'Logs';

$_['text_need_update']     = 'You need to update to the latest version !!!';