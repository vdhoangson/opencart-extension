<?php
$_['block_title'] = 'Slider';