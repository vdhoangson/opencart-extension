<?php
$_['block_title'] = 'Article Carousel';